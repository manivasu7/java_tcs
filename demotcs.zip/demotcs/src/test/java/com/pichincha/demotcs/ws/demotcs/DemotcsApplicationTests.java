package com.pichincha.demotcs.ws.demotcs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemotcsApplicationTests {

	@Test
	void contextLoads() {
	}

}

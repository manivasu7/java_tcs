package com.pichincha.demotcs.ws.demotcs.service;
import com.pichincha.demotcs.ws.demotcs.service.MovementService;
import com.pichincha.demotcs.ws.demotcs.model.Movement;
import java.util.List;

public interface MovementService {

    List<Movement> getMovement();
    Movement saveMovement(Movement movement);
    Movement updateMovement(Long id, Movement movement);
    Boolean deleteMovement(Long id);

}


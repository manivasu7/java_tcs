package com.pichincha.demotcs.ws.demotcs.controller;
import com.pichincha.demotcs.ws.demotcs.model.Movement;
import com.pichincha.demotcs.ws.demotcs.service.MovementService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/movement")
public class movementController {

    private final MovementService movementService;

    @GetMapping
    public ResponseEntity<List<Movement>>  getAllMovement(){
        try {
            return new ResponseEntity<>(movementService.getMovement(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping
    public ResponseEntity<Movement> saveMovement(@RequestBody Movement movement){
        try {
            return new ResponseEntity<>(movementService.saveMovement(movement), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping(value="{id}")
    public ResponseEntity<Movement> updateCustomer(@PathVariable Long id, @RequestBody Movement movement){
        try {
            return new ResponseEntity<>(movementService.updateMovement(id, movement), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping(value="{id}")
    public ResponseEntity deleteMovement(@PathVariable Long id){

        Boolean response = movementService.deleteMovement(id);

        if (!response)
            return new ResponseEntity<>("The movement is does not exist", HttpStatus.NOT_FOUND);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }

}

package com.pichincha.demotcs.ws.demotcs.service;
import com.pichincha.demotcs.ws.demotcs.service.AccountService;
import com.pichincha.demotcs.ws.demotcs.model.Account;
import java.util.List;

public interface AccountService {

    List<Account> getAccount();
    Account saveAccount(Account account);
    Account updateAccount(Long id, Account account);
    Boolean deleteAccount(Long id);

}


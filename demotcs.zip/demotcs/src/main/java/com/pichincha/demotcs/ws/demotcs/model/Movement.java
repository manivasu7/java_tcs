package com.pichincha.demotcs.ws.demotcs.model;

import lombok.*;
import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="tbl_movement")
public class Movement {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    private String date;
    private String value;
    private String type;


}
